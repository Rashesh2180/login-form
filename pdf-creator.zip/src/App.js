import './App.css';
import PrintPrevention from './componnets/Pdf';

function App() {
  return (
    <div className='max-w-[500px] mx-auto w-full'>
      <PrintPrevention/>
      
    </div>
  );
}

export default App;
